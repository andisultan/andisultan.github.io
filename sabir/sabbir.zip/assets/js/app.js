!function ($) {
    $(function(){
        $('#testimoni, #features').carousel();
        $('.carousel-indicators img').tooltip({
            'placement':'bottom'
        });
})

}(window.jQuery)

