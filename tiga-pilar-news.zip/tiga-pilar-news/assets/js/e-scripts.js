jQuery(document).ready(function(e){

	$('.toggle-menu').click(function(e){
		e.preventDefault();
		$('.main-menu').slideToggle();
	});
});