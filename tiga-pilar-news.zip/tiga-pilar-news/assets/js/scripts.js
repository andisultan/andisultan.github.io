jQuery(document).ready(function($){
	$("#headline-news, #gallery_left").owlCarousel({
		navigation : true, // Show next and prev buttons
		slideSpeed : 300,
		paginationSpeed : 400,
		singleItem:true,
	    navigation : false,
	    autoPlay : true,
	});

	$('.nav__search__btn').click(function(e){
		e.preventDefault();
		$('.nav__search__form').slideToggle();
	})

});

$(window).load(function(){
	$('.sidebar').stick_in_parent();
	console.log('tes');
});


// jQuery(document).ready(function(e){

// 	$(document).ready(function() {
//  		$("#headline-news").owlCarousel({
//  			// Most important owl features
// 		    items : 1,
// 		    itemsCustom : false,
// 		    itemsDesktop : [1199,4],
// 		    itemsDesktopSmall : [980,3],
// 		    itemsTablet: [768,2],
// 		    itemsTabletSmall: false,
// 		    itemsMobile : [479,1],
// 		    singleItem : false,
// 		    itemsScaleUp : false,
		 
// 		    //Basic Speeds
// 		    slideSpeed : 200,
// 		    paginationSpeed : 800,
// 		    rewindSpeed : 1000,
		 
// 		    //Autoplay
// 		    autoPlay : true,
// 		    stopOnHover : false,
		 
// 		    // Navigation
// 		    navigation : false,
// 		    navigationText : ["prev","next"],
// 		    rewindNav : true,
// 		    scrollPerPage : false,
		 
// 		    //Pagination
// 		    pagination : true,
// 		    paginationNumbers: false,
		 
// 		    // Responsive 
// 		    responsive: true,
// 		    responsiveRefreshRate : 200,
// 		    responsiveBaseWidth: window,
		 
// 		    // CSS Styles
// 		    baseClass : "owl-carousel",
// 		    theme : "owl-theme",
		 
// 		    //Lazy load
// 		    lazyLoad : false,
// 		    lazyFollow : true,
// 		    lazyEffect : "fade",
		 
// 		    //Auto height
// 		    autoHeight : false,
		 
// 		    //JSON 
// 		    jsonPath : false, 
// 		    jsonSuccess : false,
		 
// 		    //Mouse Events
// 		    dragBeforeAnimFinish : true,
// 		    mouseDrag : true,
// 		    touchDrag : true,
		 
// 		    //Transitions
// 		    transitionStyle : false,
		 
// 		    // Other
// 		    addClassActive : false,
		 
// 		    //Callbacks
// 		    beforeUpdate : false,
// 		    afterUpdate : false,
// 		    beforeInit: false, 
// 		    afterInit: false, 
// 		    beforeMove: false, 
// 		    afterMove: false,
// 		    afterAction: false,
// 		    startDragging : false
// 		    afterLazyLoad : false
//  		});
// 	});

// });